#config file containing credentials for rds mysql instance
db_endpoint = "serverless.curnqo31tnli.us-west-1.rds.amazonaws.com"
db_username = "serverless"
db_password = "y87}ve6L?2wac"
db_name = "serverless"
